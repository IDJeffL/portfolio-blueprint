import SEO from './SEO';

export default SEO;
